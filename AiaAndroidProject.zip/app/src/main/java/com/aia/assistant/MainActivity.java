package com.aia.assistant;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView status;
    private TextToSpeech tts;
    private static final int SPEECH_REQUEST = 1001;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("es", "MX"));
        });

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 36, 28, 28);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setBackgroundColor(0xFF101522);

        TextView title = new TextView(this);
        title.setText("AIA");
        title.setTextSize(36);
        title.setTextColor(0xFF8CEBFF);
        title.setGravity(Gravity.CENTER);
        page.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("Tu compañera de voz");
        subtitle.setTextSize(18);
        subtitle.setTextColor(0xFFFFFFFF);
        subtitle.setGravity(Gravity.CENTER);
        page.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        status = new TextView(this);
        status.setText("Hola, Javier creador. Soy Aia. Pulsa Hablar para comenzar.");
        status.setTextColor(0xFFFFFFFF);
        status.setTextSize(17);
        status.setPadding(0, 28, 0, 24);
        page.addView(status, new LinearLayout.LayoutParams(-1, -2));

        addButton(page, "🎙 Hablar con Aia", v -> listen());
        addButton(page, "▶ Abrir Roblox", v -> openApp("com.roblox.client", "Roblox"));
        addButton(page, "👾 Abrir Among Us", v -> openApp("com.innersloth.spacemafia", "Among Us"));
        addButton(page, "▶ YouTube Shorts", v -> openUrl("https://www.youtube.com/shorts"));
        addButton(page, "ℹ Funciones y límites", v -> {
            String msg = "Javier creador, esta es una versión inicial. Puede reconocer voz y responder con voz, y abrir aplicaciones instaladas. Para conversar libremente necesita conectarse a un servicio de IA.";
            status.setText(msg);
            say(msg);
        });

        ScrollView scroll = new ScrollView(this);
        scroll.addView(page);
        setContentView(scroll);
    }

    private void addButton(LinearLayout page, String label, View.OnClickListener action) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(action);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 8, 0, 8);
        page.addView(b, lp);
    }

    private void listen() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla con Aia");
        try { startActivityForResult(intent, SPEECH_REQUEST); }
        catch (ActivityNotFoundException e) {
            status.setText("No hay un servicio de reconocimiento de voz disponible.");
            Toast.makeText(this, "Activa o instala el reconocimiento de voz.", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SPEECH_REQUEST && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                String spoken = results.get(0);
                String reply = "Javier creador, te escuché decir: " + spoken + ". Esta versión inicial todavía necesita conectar un servicio de inteligencia artificial para responder libremente.";
                status.setText("Tú: " + spoken + "\n\nAia: " + reply);
                say(reply);
            }
        }
    }

    private void say(String text) {
        if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aia_speech");
    }

    private void openApp(String packageName, String appName) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
        if (launch != null) startActivity(launch);
        else {
            String msg = "Javier creador, no encuentro " + appName + " instalado.";
            status.setText(msg);
            Toast.makeText(this, appName + " no está instalado.", Toast.LENGTH_LONG).show();
        }
    }

    private void openUrl(String url) {
        Intent launch = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url));
        try { startActivity(launch); }
        catch (ActivityNotFoundException e) { status.setText("No se pudo abrir el enlace."); }
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
