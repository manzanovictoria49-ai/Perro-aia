AIA - proyecto inicial para Android

Esta carpeta contiene el código fuente de una primera versión de Aia:
- Pantalla de inicio
- Reconocimiento de voz en español (usa el servicio de voz del teléfono)
- Respuesta hablada con Text-to-Speech
- Accesos para abrir Roblox, Among Us y YouTube Shorts si están disponibles

IMPORTANTE:
Este archivo ZIP NO es una APK instalada. En este entorno no hay Android SDK/Gradle configurado para compilar y firmar el APK. Para generar la APK:
1. Instala Android Studio en una computadora.
2. Abre la carpeta AiaAndroidProject.
3. Espera a que Gradle sincronice y descargue las herramientas necesarias.
4. Selecciona Build > Build APK(s).
5. El APK de depuración normalmente queda en app/build/outputs/apk/debug/app-debug.apk.

Limitaciones de esta versión:
- No es todavía un asistente de IA conectado; por ahora repite lo que reconoce y explica que necesita un servicio de IA.
- No mantiene una llamada/escucha continua en segundo plano.
- Los accesos a otras aplicaciones solo funcionan si están instaladas.
- No filtra automáticamente el contenido de YouTube Shorts.
